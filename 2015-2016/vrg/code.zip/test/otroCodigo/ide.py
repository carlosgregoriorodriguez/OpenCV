import Tkinter as tk

root = tk.Tk()
root.resizable(width=False, height=False)
root.geometry('1000x720')

root.mainloop()