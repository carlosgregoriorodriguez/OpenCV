********
Coloring
********

.. automodule:: networkx.algorithms.coloring
.. autosummary::
   :toctree: generated/

   greedy_color
